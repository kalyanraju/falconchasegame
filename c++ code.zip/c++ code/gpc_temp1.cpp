#include "gpc_temp.h"
namespace __GLBASIC__{
/* GBAS: F:\docments\GLBasic\Samples\_Projects_\GLBasic_intro_2D\GLBasic_intro_2D.gbas */
} // namespace
