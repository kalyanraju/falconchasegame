#include "gpc_temp.h"
namespace __GLBASIC__{
int __MainGameSub_(void)
{
#undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
/* GBAS: C:\Documents and Settings\kalyan\My Documents\Falcon Chase game\S-Zero.gbas */
// --------------------------------- // 
// Project:falcon chase 
// Start: Sunday, May 25, 2003 
// Compiler Version: 1.30520 
												ON_DEBUG ( 0, 4 );
REGISTER_VAR_DEF(DGInt, phi, 0);
REGISTER_VAR_DEF(DGInt, d1, 0);
REGISTER_VAR_DEF(DGInt, d2, 0);
REGISTER_VAR_DEF(DGInt, camx, 0);
REGISTER_VAR_DEF(DGInt, camy, 0);
REGISTER_VAR_DEF(DGInt, camz, 0);
REGISTER_VAR_DEF(DGInt, camback, 0);
REGISTER_VAR_DEF(DGInt, camfront, 0);
REGISTER_VAR_DEF(DGInt, delta_time, 0);
												ON_DEBUG ( 0, 5 );
												ON_DEBUG ( 0, 6 );
lft=0;
												ON_DEBUG ( 0, 7 );
d=0;
//	globtext$="                     This is a first preview of a 3D game created with GLBasic. The whole source code ascii file (S-Zero.gbas) is only 500 lines (15kB) " 
//	globtext$=globtext$+"If you want to write your own 3D game with the easiest basic language around, contact www.glbasic.com. " 
//	globtext$=globtext$+"Greetings to: Pia, Markus, Roli, Wolfi, Hemlos and all of my friends." 
												ON_DEBUG ( 0, 13 );	
GETSCREENSIZE( screenx, screeny);
												ON_DEBUG ( 0, 14 );	
if (screenx < 640 )
LOADFONT( CGStr("Data/smalfont1.bmp"), 0);
												ON_DEBUG ( 0, 15 );	
GETFONTSIZE( fntx, fnty);
												ON_DEBUG ( 0, 16 );
SETSCREEN( 640,480,1);
												ON_DEBUG ( 0, 17 );
name_Str=CGStr("Name: ") ;
												ON_DEBUG ( 0, 18 );
INPUT( name_Str,120,202);
												ON_DEBUG ( 0, 19 );
inst_Str=CGStr("Institution name: ") ;
												ON_DEBUG ( 0, 20 );
INPUT( inst_Str,120,204);
												ON_DEBUG ( 0, 21 );
mof_Str=CGStr("Male/Female: ") ;
												ON_DEBUG ( 0, 22 );
INPUT( mof_Str,120,206);
												ON_DEBUG ( 0, 24 );
objects:;
												ON_DEBUG ( 0, 25 );	
Statusbar(0) ;
												ON_DEBUG ( 0, 26 );	
LOADSPRITE( CGStr("Data/track0.bmp"), 0);
												ON_DEBUG ( 0, 27 );	
LOADSPRITE( CGStr("Data/start.bmp"),18);
												ON_DEBUG ( 0, 28 );	
LOADSPRITE( CGStr("Data/male.bmp"),19);
												ON_DEBUG ( 0, 29 );	
LOADSOUND( CGStr("Data/Monster1.wav"),7,1);
												ON_DEBUG ( 0, 30 );	
LOADSOUND( CGStr("Data/water1.wav"),6,1);
												ON_DEBUG ( 0, 31 );	
LOADSOUND( CGStr("Data/laser.wav"),2,1);
												ON_DEBUG ( 0, 32 );	
LOADSOUND( CGStr("Data/Explo.wav"),3,1);
												ON_DEBUG ( 0, 33 );	
LOADSOUND( CGStr("Data/over.wav"),4,1);
												ON_DEBUG ( 0, 34 );	
LOADSOUND( CGStr("Data/Bullet.wav"),5,1);
												ON_DEBUG ( 0, 35 );	
X_LOADOBJ( CGStr("Data/croc.ddd"),22);
												ON_DEBUG ( 0, 36 );	
LOADSPRITE( CGStr("Data/croc.bmp"),22);
												ON_DEBUG ( 0, 37 );	
X_LOADOBJ( CGStr("Data/tree.ddd"),23);
												ON_DEBUG ( 0, 38 );	
LOADSPRITE( CGStr("Data/tree.bmp"),23);
												ON_DEBUG ( 0, 39 );	
X_LOADOBJ( CGStr("Data/drag.ddd"),24);
												ON_DEBUG ( 0, 40 );	
Statusbar(0.025) ;
												ON_DEBUG ( 0, 41 );	
LOADSPRITE( CGStr("Data/hud.bmp"), 50);
												ON_DEBUG ( 0, 42 );	
Statusbar(0.05) ;
												ON_DEBUG ( 0, 44 );	
X_LOADOBJ( CGStr("Data/car.ddd"), 1);
												ON_DEBUG ( 0, 45 );	
X_LOADOBJ( CGStr("Data/mis.ddd"), 17);
												ON_DEBUG ( 0, 46 );	
Statusbar(0.1) ;
												ON_DEBUG ( 0, 47 );	
LOADSPRITE( CGStr("Data/engine1.bmp"), 1);
												ON_DEBUG ( 0, 48 );	
X_LOADOBJ( CGStr("Data/engine1.ddd"), 16);
												ON_DEBUG ( 0, 49 );	
Statusbar(0.15) ;
												ON_DEBUG ( 0, 50 );	
LOADSPRITE( CGStr("Data/engine1e.bmp"), 2);
												ON_DEBUG ( 0, 51 );	
Statusbar(0.2) ;
												ON_DEBUG ( 0, 52 );	
LOADSPRITE( CGStr("Data/engine1s.bmp"), 9);
												ON_DEBUG ( 0, 53 );	
Statusbar(0.25) ;
// 10 = Track 
												ON_DEBUG ( 0, 56 );	
Statusbar(0.3) ;
												ON_DEBUG ( 0, 57 );	
X_LOADOBJ( CGStr("Data/burner.ddd"), 11);
												ON_DEBUG ( 0, 58 );	
Statusbar(0.35) ;
												ON_DEBUG ( 0, 59 );	
X_LOADOBJ( CGStr("Data/skybox.ddd"), 12);
												ON_DEBUG ( 0, 60 );	
Statusbar(0.4) ;
												ON_DEBUG ( 0, 61 );	
LOADSPRITE( CGStr("Data/sky2.bmp"), 12);
												ON_DEBUG ( 0, 62 );	
LOADSPRITE( CGStr("Data/tree2.bmp"),20);
												ON_DEBUG ( 0, 63 );	
X_LOADOBJ( CGStr("Data/tree2.ddd"),20);
												ON_DEBUG ( 0, 64 );	
X_LOADOBJ( CGStr("Data/ship.ddd"),21);
												ON_DEBUG ( 0, 66 );	
Statusbar(0.5) ;
												ON_DEBUG ( 0, 67 );		
X_OBJSTART( 13);
												ON_DEBUG ( 0, 68 );		
X_OBJADDVERTEX( -150, 0,  -150,  0,  0, RGB(255,255,255) );
												ON_DEBUG ( 0, 69 );		
X_OBJADDVERTEX(  150, 0,  -150, 500,  0, RGB(255,255,255) );
												ON_DEBUG ( 0, 70 );		
X_OBJADDVERTEX( -150, 0,  150,  0, 250, RGB(255,255,255) );
												ON_DEBUG ( 0, 71 );		
X_OBJADDVERTEX(  150, 0,  150, 500, 250, RGB(255,255,255) );
												ON_DEBUG ( 0, 72 );	
X_OBJEND();
												ON_DEBUG ( 0, 73 );	
Statusbar(0.55) ;
												ON_DEBUG ( 0, 74 );	
LOADSPRITE( CGStr("Data/back1.bmp"), 13);
												ON_DEBUG ( 0, 76 );	
Statusbar(0.59) ;
												ON_DEBUG ( 0, 77 );	
X_LOADOBJ(  CGStr("Data/gate.ddd"), 14);
												ON_DEBUG ( 0, 78 );	
Statusbar(0.62) ;
												ON_DEBUG ( 0, 79 );	
LOADSPRITE( CGStr("Data/gate.bmp"), 14);
												ON_DEBUG ( 0, 81 );	
Statusbar(0.67) ;
												ON_DEBUG ( 0, 82 );	
X_LOADOBJ(  CGStr("Data/MOUNTS.ddd"), 15);
												ON_DEBUG ( 0, 83 );	
Statusbar(0.7) ;
												ON_DEBUG ( 0, 84 );	
LOADSPRITE( CGStr("Data/build1.bmp"), 15);
												ON_DEBUG ( 0, 86 );	
LOADSOUND( CGStr("Data/ready.wav"),1,1);
												ON_DEBUG ( 0, 87 );	
Statusbar(0.75) ;
												ON_DEBUG ( 0, 89 );
BEGIN:;
												ON_DEBUG ( 0, 90 );	
start() ;
												ON_DEBUG ( 0, 91 );
DIM(ship_pos, 10,3);
// num, xyz 
												ON_DEBUG ( 0, 92 );
DIM(ship_dir, 10,3);
// num, phi+yaw+directional 
												ON_DEBUG ( 0, 93 );
DIM(ship_spd, 10);
												ON_DEBUG ( 0, 95 );
DIM(fire_pos, 10,3);
												ON_DEBUG ( 0, 96 );
DIM(mean_phi, 100);
												ON_DEBUG ( 0, 97 );
DIM(mean_typ, 100);
												ON_DEBUG ( 0, 98 );
DIM(mean_pos, 100,3);
												ON_DEBUG ( 0, 100 );
DIM(best_times, 10);
												ON_DEBUG ( 0, 101 );	
Statusbar(0.88) ;
												ON_DEBUG ( 0, 103 );	
for (i = 0 ; i<= 9; i++)
{
												ON_DEBUG ( 0, 104 );		
best_times(i) = 1200;
// 2 min 
												ON_DEBUG ( 0, 105 );	
}
												ON_DEBUG ( 0, 107 );	
max_means = 15;
												ON_DEBUG ( 0, 108 );	
for (i = 0 ; i<= max_means; i++)
{
												ON_DEBUG ( 0, 109 );		
mean_phi(i) = -i;
// 360/max_means * i 
												ON_DEBUG ( 0, 110 );		
mean_typ(i) = MOD(i, 4) ;
												ON_DEBUG ( 0, 111 );	
}
												ON_DEBUG ( 0, 113 );	
camback=5;
camfront = 20;
												ON_DEBUG ( 0, 114 );	
Statusbar(1.0) ;
												ON_DEBUG ( 0, 118 ); 
g_Level = StageSelect();
// StageSelect() 
												ON_DEBUG ( 0, 120 );	
ship_pos(0,0) = DistAtPhi(g_Level-1, 0) ;
												ON_DEBUG ( 0, 121 );	
ship_pos(0,1) = HeightAtPhi(g_Level, 0) ;
												ON_DEBUG ( 0, 122 );	
ship_pos(0,2) = 0;
												ON_DEBUG ( 0, 123 );	
ship_spd(0) = 0;
// 25 
												ON_DEBUG ( 0, 124 );	
ship_dir(0,0) = DirAtPhi(g_Level, 0) ;
												ON_DEBUG ( 0, 127 );	
PrepareTrackObjects(g_Level, 1.0) ;
												ON_DEBUG ( 0, 128 );	
SETMOUSE( 320,0);
												ON_DEBUG ( 0, 129 );	
HUSH();
												ON_DEBUG ( 0, 130 );	
PLAYSOUND (1,0,1) ;
												ON_DEBUG ( 0, 131 ); 
PLAYMUSIC( CGStr("Data/track2.mid") );
												ON_DEBUG ( 0, 132 );
main:;
												ON_DEBUG ( 0, 134 );	
while( TRUE)
{
												ON_DEBUG ( 0, 135 );	
PLAYSOUND(6,0,1) ;
												ON_DEBUG ( 0, 136 );	
snd=RND(100) ;
												ON_DEBUG ( 0, 137 );	
if (snd==1 )
PLAYSOUND(7,0,1) ;
												ON_DEBUG ( 0, 138 );	
snd=0;
												ON_DEBUG ( 0, 139 );	
if (KEY(1) )
{
												ON_DEBUG ( 0, 140 );	
HUSH();
												ON_DEBUG ( 0, 141 );	 
goto BEGIN;
												ON_DEBUG ( 0, 142 );	 
}
												ON_DEBUG ( 0, 143 );		
if (max_means==-1 OR KEY(64)OR KEY(01) )
details(0) ;
												ON_DEBUG ( 0, 144 );		
if (damage*100>100 )
details(1) ;
												ON_DEBUG ( 0, 145 );		
phi = CheckCollision(g_Level, phi, max_means) ;
												ON_DEBUG ( 0, 146 );		
MovePlayer(g_Level, delta_time, phi) ;
												ON_DEBUG ( 0, 147 );		
MoveMeans(g_Level, delta_time, max_means) ;
												ON_DEBUG ( 0, 149 );		
phi = ATAN(ship_pos(0,2), ship_pos(0,0)) ;
												ON_DEBUG ( 0, 150 );		
d1 = DistAtPhi(g_Level, phi-camback) ;
												ON_DEBUG ( 0, 151 );		
d2 = DistAtPhi(g_Level, phi+camfront) ;
												ON_DEBUG ( 0, 152 );		
camx = d1*COS(phi-camback) ;
												ON_DEBUG ( 0, 153 );		
camy = 50 + HeightAtPhi(g_Level, phi-camback) ;
												ON_DEBUG ( 0, 154 );		
camz = d1*SIN(phi-camback) ;
												ON_DEBUG ( 0, 156 );		
X_MAKE3D( 10, 4069, 60);
												ON_DEBUG ( 0, 157 );		
X_MIPMAPPING( TRUE);
												ON_DEBUG ( 0, 158 );		
X_CAMERA( camx, camy, camz, ship_pos(0,0), ship_pos(0,1)+60, ship_pos(0,2) );
// Skybox 
												ON_DEBUG ( 0, 162 );		
X_MOVEMENT( camx, -600, camz);
												ON_DEBUG ( 0, 163 );		
X_SCALING( 1, 1, 1);
												ON_DEBUG ( 0, 164 );		
X_SETTEXTURE( 12,-1);
												ON_DEBUG ( 0, 165 );		
X_DRAWOBJ( 12, 0);
												ON_DEBUG ( 0, 166 );		
X_CLEAR_Z();
												ON_DEBUG ( 0, 170 );		
if (camy>-40)
{
												ON_DEBUG ( 0, 171 );			
col=RGB(255, 255, 255) ;
												ON_DEBUG ( 0, 172 );		
}
else
{
												ON_DEBUG ( 0, 173 );			
col=RGB(64, 64, 55) ;
												ON_DEBUG ( 0, 174 );		
}
//X_AMBIENT_LT 0,RGB(255,255,255) 
												ON_DEBUG ( 0, 176 );		
X_SPOT_LT( -2, RGB(255,255,255), 0,100,0, 100, -10, 0,0);
												ON_DEBUG ( 0, 177 );		
if (KEY(42) )
X_CAMERA( ship_pos(0,0), ship_pos(0,1)+700, ship_pos(0,2)-500,    ship_pos(0,0), ship_pos(0,1)+5, ship_pos(0,2) );
// Top view to ship 
												ON_DEBUG ( 0, 178 );		
if (KEY(29) )
X_CAMERA( 0, 400, -2500,    0,0,0);
// Overview of all 
												ON_DEBUG ( 0, 179 );		
if (KEY(15) )
X_CAMERA( ship_pos(0,0), ship_pos(0,1)-700, ship_pos(0,2)+700,    ship_pos(0,0)+10, ship_pos(0,1), ship_pos(0,2) );
												ON_DEBUG ( 0, 181 );		
if (KEY(2) )
LIMITFPS( 30);
												ON_DEBUG ( 0, 182 );		
if (KEY(3) )
LIMITFPS( 60);
												ON_DEBUG ( 0, 183 );		
if (KEY(4) )
LIMITFPS( -1);
//	X_CULLMODE 1 
												ON_DEBUG ( 0, 186 );		
X_SETTEXTURE( 0,-1);
// We draw the track in absolute coords 
												ON_DEBUG ( 0, 188 );		
X_SCALING( 1,1,1);
X_MOVEMENT( 0,0,0);
												ON_DEBUG ( 0, 189 );		
X_DRAWOBJ( 10, 0);
												ON_DEBUG ( 0, 191 );	
X_MOVEMENT( (camx+1500), 200, 250);
												ON_DEBUG ( 0, 192 );	
X_ROTATION( (camx*10+180),0,1,0);
												ON_DEBUG ( 0, 193 );		
X_SCALING( 150, 150, 150);
												ON_DEBUG ( 0, 194 );		
X_SETTEXTURE( 9,-1);
												ON_DEBUG ( 0, 195 );		
X_DRAWOBJ( 24, 0);
												ON_DEBUG ( 0, 197 );
X_MOVEMENT( (camx+500), 60, camy-1000);
												ON_DEBUG ( 0, 198 );	
X_ROTATION( -(camx*10+90),0,1,0);
												ON_DEBUG ( 0, 199 );		
X_SCALING( 100, 100, 100);
												ON_DEBUG ( 0, 200 );		
X_SETTEXTURE( 9,-1);
												ON_DEBUG ( 0, 201 );		
X_DRAWOBJ( 24, 0);
												ON_DEBUG ( 0, 203 );
X_SPOT_LT( 0, RGB(255,255,255), 0,100,0, 100, -10, 0,0);
// Ship 
												ON_DEBUG ( 0, 206 );		
X_MOVEMENT( ship_pos(0,0)+30, ship_pos(0,1)+8+lft, ship_pos(0,2) );
												ON_DEBUG ( 0, 207 );		
X_SCALING( 4, 4,4);
												ON_DEBUG ( 0, 208 );		
X_ROTATION( ship_dir(0,2)*10, 1,0, 0);
												ON_DEBUG ( 0, 209 );		
X_ROTATION( ship_dir(0,0)+90, 0, 1, 0);
												ON_DEBUG ( 0, 210 );		
X_SETTEXTURE( 9,-1);
												ON_DEBUG ( 0, 211 );		
X_DRAWOBJ( 1, 0);
//	X_SPOT_LT -1, RGB(255,255,255), 0,100,0, ship_pos[0][0]+30, ship_pos[0][1]+8+lft, ship_pos[0][2],0 
//	X_SPOT_LT -1, RGB(0,255,255), ship_pos[0][0]+30, ship_pos[0][1]+8+lft, ship_pos[0][2],ship_pos[0][0]+30, ship_pos[0][1], ship_pos[0][2],0 
												ON_DEBUG ( 0, 215 );
if (KEY(57) )
fire() ;
												ON_DEBUG ( 0, 217 );	
if (SOUNDPLAYING(chk) )
attack() ;
												ON_DEBUG ( 0, 218 );	
if (damage>25 AND damage<50 )
ship_spd(0)=ship_spd(0)+20;
												ON_DEBUG ( 0, 219 );	
if (damage>50 AND damage<70 )
ship_spd(0)=ship_spd(0)+40;
// Flame 
												ON_DEBUG ( 0, 223 );		
X_CULLMODE( 0);
												ON_DEBUG ( 0, 224 );		
ALPHAMODE( 1);
												ON_DEBUG ( 0, 225 );		
X_SCALING( 1, 1, ship_spd(0) );
												ON_DEBUG ( 0, 226 );		
X_MOVEMENT( ship_pos(0,0)+30, ship_pos(0,1)+8+lft, ship_pos(0,2) );
//X_ROTATION 50, 0, 0,1 
												ON_DEBUG ( 0, 228 );		
X_ROTATION( ship_dir(0,0)+180, 0, 1, 0);
												ON_DEBUG ( 0, 229 );		
X_DRAWOBJ( 11,0);
// Shadow 
//X_CULLMODE 1 
//	X_SETTEXTURE 9, -1 
//	X_MOVEMENT ship_pos[0][0], ship_pos[0][1], ship_pos[0][2] 
//	X_SCALING 3, 3, 3 
//	X_ROTATION 180, 0, 0, 1 
//	X_ROTATION ship_dir[0][0]+270, 0, 1, 0 
//	ALPHAMODE -.7 
//	X_DRAWOBJ 1, 0 
//	ALPHAMODE 0 
												ON_DEBUG ( 0, 244 );		
ShowMeans(g_Level, max_means) ;
												ON_DEBUG ( 0, 245 );		
DrawEnvironment(g_Level) ;
//X_SPOT_LT -2, RGB(255,55,25), ship_pos[0][0]+30, ship_pos[0][1]+8+lft, ship_pos[0][2],ship_pos[0][0]+30, ship_pos[0][1], ship_pos[0][2],0 
//X_SPOT_LT -2, RGB(255,255,255), ship_pos[0][0]+30, ship_pos[0][1]+8+lft, ship_pos[0][2],ship_pos[0][0]+30, ship_pos[0][1], ship_pos[0][2],0 
												ON_DEBUG ( 0, 248 );		
ALPHAMODE( 0);
// surface 
												ON_DEBUG ( 0, 250 );		
X_CULLMODE( 0);
												ON_DEBUG ( 0, 251 );		
X_SETTEXTURE( 13,-1);
												ON_DEBUG ( 0, 252 );		
ALPHAMODE( .5);
												ON_DEBUG ( 0, 253 );		
X_MOVEMENT( 0,-30,0);
												ON_DEBUG ( 0, 254 );		
X_SCALING( 300, 300, 300);
												ON_DEBUG ( 0, 255 );		
X_DRAWOBJ( 13, 0);
												ON_DEBUG ( 0, 256 );		
ALPHAMODE( 0);
// 2D drawings 
												ON_DEBUG ( 0, 259 );		
X_MAKE2D();
												ON_DEBUG ( 0, 260 );			
if (last_phi>phi AND phi<1)
{
												ON_DEBUG ( 0, 261 );			
if (lap_time < best_times(g_Level) )
{
												ON_DEBUG ( 0, 262 );				
best_times(g_Level) = lap_time;
												ON_DEBUG ( 0, 263 );			
}
												ON_DEBUG ( 0, 264 );			
lap_time=0;
												ON_DEBUG ( 0, 265 );		
}
// Speed-o-meter 
												ON_DEBUG ( 0, 267 );		
y_pos = 480-128;
												ON_DEBUG ( 0, 268 );		
ALPHAMODE( 0);
												ON_DEBUG ( 0, 269 );		
for (x = 0 ; x<= ship_spd(0)*11.7; x++)
{
// 
												ON_DEBUG ( 0, 270 );		
DRAWLINE( 41+x, y_pos+10, 41+x, y_pos+12+x/10, RGB(SIN(x/3)*255, 255-SIN(x/6)*255, 50) );
												ON_DEBUG ( 0, 271 );		
}
// Curve-o-meter 
												ON_DEBUG ( 0, 273 );		
FILLRECT( 186, 362, 186+ship_dir(0,2)*16, 364, RGB(255,0,0) );
												ON_DEBUG ( 0, 274 );		
ALPHAMODE( 0);
												ON_DEBUG ( 0, 275 );		
SPRITE( 50, 0, y_pos);
// Draw track as 2d-graphics 
												ON_DEBUG ( 0, 278 );		
if (KEY(42) )
{
												ON_DEBUG ( 0, 279 );			
for (x = 0 ; x<= 360; x++)
{
												ON_DEBUG ( 0, 280 );			
FILLRECT( x, DistAtPhi(g_Level, x), x+1, DistAtPhi(g_Level, x), RGB(255, 2, 2) );
												ON_DEBUG ( 0, 281 );			
}
												ON_DEBUG ( 0, 282 );		
}
												ON_DEBUG ( 0, 284 );	
if (y==1 )
PRINT( CGStr("mission completed"), 150,50);
// FPS counter: 
												ON_DEBUG ( 0, 286 );		
if (delta_time>3)
{
												ON_DEBUG ( 0, 287 );			
fps = ((10000/delta_time)+fps)/2;
												ON_DEBUG ( 0, 288 );			
delay=delay+delta_time;
												ON_DEBUG ( 0, 289 );			
if (delay>1000)
{
// 1/2 sec 
												ON_DEBUG ( 0, 290 );				
delay=0;
												ON_DEBUG ( 0, 291 );				
ShowFPS=fps;
												ON_DEBUG ( 0, 292 );			
}
												ON_DEBUG ( 0, 293 );			
if (fps>1000 )
fps=0;
												ON_DEBUG ( 0, 294 );		
}
												ON_DEBUG ( 0, 295 );		
PRINT( CGStr("FPS: ") + INTEGER(ShowFPS) + CGStr(" @ ") + delta_time, 0, screeny-fnty);
// + dtime, 0,0 
// New lap? 
// Lap time 
												ON_DEBUG ( 0, 300 );		
lap_time=lap_time+delta_time;
												ON_DEBUG ( 0, 301 );		
PRINT( CGStr("chase time: ") + NiceTime_Str(lap_time) + CGStr(" Spd: ") + FORMAT_Str(5,1,ship_spd(0)*10), 0, 0);
												ON_DEBUG ( 0, 302 );		
PRINT( CGStr("score: ")+((score)*100),0,200);
												ON_DEBUG ( 0, 303 );		
PRINT( CGStr("Damage: ")+(damage*100)+CGStr("%"),0,220);
												ON_DEBUG ( 0, 304 );		
PRINT( CGStr("Best:") + NiceTime_Str(best_times(g_Level)), 0, 20);
												ON_DEBUG ( 0, 305 );		
last_phi=phi;
												ON_DEBUG ( 0, 307 );		
delta_time = GETTIMER() ;
												ON_DEBUG ( 0, 308 );		
SHOWSCREEN();
												ON_DEBUG ( 0, 310 );	
}
// ----------------------------------------- // 
// Display time nicely 
// ----------------------------------------- // 
												ON_DEBUG ( 0, 315 );
return 0;
}
// ------------------------ //
DGStr NiceTime_Str(DGInt misecs)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, misecs);
												ON_DEBUG ( 0, 316 );	
REGISTER_VAR_DEF(DGInt, mns, 0);
REGISTER_VAR_DEF(DGInt, sec, 0);
REGISTER_VAR_DEF(DGInt, ten, 0);
REGISTER_VAR(DGStr, a_Str);
												ON_DEBUG ( 0, 317 );	
mns = INTEGER(misecs/60000);
misecs=misecs-mns*60000;
												ON_DEBUG ( 0, 318 );	
sec = INTEGER(misecs/1000);
misecs=misecs-sec*1000;
												ON_DEBUG ( 0, 319 );	
ten = INTEGER(misecs/100) ;
												ON_DEBUG ( 0, 320 );	
a_Str = CGStr("") + mns + CGStr("'") + sec + CGStr("''") + ten;
												ON_DEBUG ( 0, 321 );
return a_Str ;
												ON_DEBUG ( 0, 322 );
return 0;
}
// ----------------------------------------- // 
// Draw the environment for each level (house blocks...) 
// ----------------------------------------- // 
// ------------------------ //
DGInt DrawEnvironment(DGInt nLevel)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, nLevel);
												ON_DEBUG ( 0, 328 );	
REGISTER_VAR_DEF(DGInt, d, 0);
REGISTER_VAR_DEF(DGInt, p, 0);
//	 Gate 
												ON_DEBUG ( 0, 330 );
X_MOVEMENT( DistAtPhi(nLevel, 0)+100, HeightAtPhi(nLevel, 0), 0);
												ON_DEBUG ( 0, 331 );	
X_SCALING( WidthAtPhi(nLevel, 0)/40, 60, 100);
												ON_DEBUG ( 0, 332 );	
X_ROTATION( DirAtPhi(nLevel, 0), 0,1,0);
												ON_DEBUG ( 0, 333 );		
X_SETTEXTURE( 20,-1);
												ON_DEBUG ( 0, 334 );	
X_DRAWOBJ( 20, 0);
												ON_DEBUG ( 0, 336 );	
X_MOVEMENT( DistAtPhi(nLevel, 0), HeightAtPhi(nLevel, 0), 0);
												ON_DEBUG ( 0, 337 );	
X_SCALING( WidthAtPhi(nLevel, 0)/40, 1, 1);
												ON_DEBUG ( 0, 338 );	
X_ROTATION( DirAtPhi(nLevel, 0), 0,1,0);
												ON_DEBUG ( 0, 339 );	
X_SETTEXTURE( 14,-1);
												ON_DEBUG ( 0, 340 );	
X_DRAWOBJ( 14, 0);
												ON_DEBUG ( 0, 341 );
X_MOVEMENT( camx*10, -50, d*SIN(p)-1000);
												ON_DEBUG ( 0, 342 );	
X_SCALING( 200, 200, 200);
												ON_DEBUG ( 0, 343 );	
X_ROTATION( DirAtPhi(nLevel, 0)+phi, 1,0,0);
												ON_DEBUG ( 0, 344 );	
X_SETTEXTURE( 22,-1);
												ON_DEBUG ( 0, 345 );	
X_DRAWANIM( 22, 0, 4, phi*100 /15, TRUE);
												ON_DEBUG ( 0, 348 );
for (p  = 30 ; ( 50)<0 ? ((p )>=(360 )) :((p )<=(360 )); p +=( 50))
{
												ON_DEBUG ( 0, 349 );
d = DistAtPhi(nLevel, p) * .65;
												ON_DEBUG ( 0, 350 );
phi=GETTIMER()/100;
												ON_DEBUG ( 0, 351 );	
X_MOVEMENT( d*COS(p)+1000, -50, d*SIN(p)-1000);
												ON_DEBUG ( 0, 352 );	
X_SCALING( 200, 200, 200);
												ON_DEBUG ( 0, 353 );	
X_ROTATION( DirAtPhi(nLevel, 0)+phi, 1,0,0);
												ON_DEBUG ( 0, 354 );	
X_SETTEXTURE( 22,-1);
												ON_DEBUG ( 0, 355 );	
X_DRAWANIM( 22, 0, 4, phi*100 /15, TRUE);
												ON_DEBUG ( 0, 357 );			
X_MOVEMENT( d*COS(290)+1500, -60, d*SIN(290)-1400);
												ON_DEBUG ( 0, 358 );	
X_SCALING( 100, 200, 200);
												ON_DEBUG ( 0, 359 );	
X_ROTATION( DirAtPhi(nLevel, 0)+phi, 1,0,0);
												ON_DEBUG ( 0, 360 );	
X_SETTEXTURE( 21,1);
												ON_DEBUG ( 0, 361 );	
X_DRAWANIM( 21, 0, 4, MOD(phi*100 / 15, 100)/100.0, TRUE);
												ON_DEBUG ( 0, 363 );		
X_MOVEMENT( d*COS(p), -60, d*SIN(p) );
// On top of water 
												ON_DEBUG ( 0, 364 );		
X_SCALING( 100,200,200);
												ON_DEBUG ( 0, 365 );		
X_SETTEXTURE( 15,-1);
												ON_DEBUG ( 0, 366 );		
X_DRAWOBJ( 15, 0);
												ON_DEBUG ( 0, 367 );	
}
												ON_DEBUG ( 0, 369 );
return 0;
}
// ----------------------------------------- // 
// DISTATPHI returns the distance of the center of the 
// track for the given angle phi 
// ----------------------------------------- // 
// ------------------------ //
DGInt DistAtPhi(DGInt nLevel, DGInt phi)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, nLevel);
ARGS_VAR(DGInt, phi);
												ON_DEBUG ( 0, 375 );	
// select:
if (FALSE){
												ON_DEBUG ( 0, 376 );	
} else if( (nLevel) == (1) ){												ON_DEBUG ( 0, 377 );		
return 1900+200*SIN(phi) ;
// Simple circle 
												ON_DEBUG ( 0, 378 );	
} else if( (nLevel) == (2) ){												ON_DEBUG ( 0, 379 );		
return 500+(2+SIN(2*phi))*1500;
												ON_DEBUG ( 0, 380 );	
} else if( (nLevel) == (3) ){												ON_DEBUG ( 0, 381 );		
return 500+(4+SIN(phi*3)*COS(phi)) * 1400;
												ON_DEBUG ( 0, 382 );	
} else if( (nLevel) == (4) ){												ON_DEBUG ( 0, 383 );		
return 1900+200*SIN(phi) ;
												ON_DEBUG ( 0, 384 );	
}
												ON_DEBUG ( 0, 385 );
return 0;
}
// ----------------------------------------- // 
// Height of the track for the given angle phi 
// ----------------------------------------- // 
// ------------------------ //
DGInt HeightAtPhi(DGInt nLevel, DGInt phi)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, nLevel);
ARGS_VAR(DGInt, phi);
												ON_DEBUG ( 0, 390 );	
// select:
if (FALSE){
												ON_DEBUG ( 0, 391 );	
} else if( (nLevel) == (1) ){												ON_DEBUG ( 0, 392 );		
return 80*SIN(phi) ;
// Flat ground 
												ON_DEBUG ( 0, 393 );	
} else if( (nLevel) == (2) ){												ON_DEBUG ( 0, 394 );		
return 150*SIN(phi) ;
												ON_DEBUG ( 0, 395 );	
} else if( (nLevel) == (3) ){												ON_DEBUG ( 0, 396 );		
return 80*COS(phi) ;
												ON_DEBUG ( 0, 397 );	
} else if( (nLevel) == (4) ){												ON_DEBUG ( 0, 398 );		
return 80+SIN(phi) ;
												ON_DEBUG ( 0, 399 );	
}
												ON_DEBUG ( 0, 400 );
return 0;
}
// ----------------------------------------- // 
// Width of the track for the given angle phi 
// ----------------------------------------- // 
// ------------------------ //
DGInt WidthAtPhi(DGInt nLevel, DGInt phi)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, nLevel);
ARGS_VAR(DGInt, phi);
												ON_DEBUG ( 0, 406 );	
// select:
if (FALSE){
												ON_DEBUG ( 0, 407 );	
} else if( (nLevel) == (1) ){												ON_DEBUG ( 0, 408 );		
return 180;
// Constant width 
												ON_DEBUG ( 0, 409 );	
} else if( (nLevel) == (2) ){												ON_DEBUG ( 0, 410 );		
return 180 + (1+COS(phi))*30;
												ON_DEBUG ( 0, 411 );	
} else if( (nLevel) == (3) ){												ON_DEBUG ( 0, 412 );		
return 180 + (1+SIN(phi*3))*20;
												ON_DEBUG ( 0, 413 );	
} else if( (nLevel) == (4) ){												ON_DEBUG ( 0, 414 );		
return 180;
												ON_DEBUG ( 0, 415 );	
}
												ON_DEBUG ( 0, 416 );
return 0;
}
// ----------------------------------------- // 
// Direction of the track for the given angle phi 
// ----------------------------------------- // 
// ------------------------ //
DGInt DirAtPhi(DGInt nLevel, DGInt phi)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, nLevel);
ARGS_VAR(DGInt, phi);
												ON_DEBUG ( 0, 422 );
REGISTER_VAR_DEF(DGInt, dist, 0);
												ON_DEBUG ( 0, 423 );	
dist = DistAtPhi(nLevel, phi-0.001) ;
												ON_DEBUG ( 0, 424 );	
return ATAN(DistAtPhi(nLevel, phi)-dist, TAN(.001) * dist) - phi;
												ON_DEBUG ( 0, 425 );
return 0;
}
// ----------------------------------------- // 
// Get the 'real' track length in a given range 
// ----------------------------------------- // 
// ------------------------ //
DGInt RangeLength(DGInt nLevel, DGInt phifrom, DGInt phito)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, nLevel);
ARGS_VAR(DGInt, phifrom);
ARGS_VAR(DGInt, phito);
												ON_DEBUG ( 0, 431 );
REGISTER_VAR(DGIntArray, p1);
REGISTER_VAR_DEF(DGInt, d, 0);
												ON_DEBUG ( 0, 432 );
DIM(p1, 3);
												ON_DEBUG ( 0, 433 );	
d = DistAtPhi(nLevel, phifrom) ;
												ON_DEBUG ( 0, 434 );	
p1(0) = COS(phifrom)*d;
												ON_DEBUG ( 0, 435 );	
p1(2) = SIN(phifrom)*d;
												ON_DEBUG ( 0, 436 );	
p1(1) = HeightAtPhi(nLevel, phifrom) ;
												ON_DEBUG ( 0, 438 );	
d = DistAtPhi(nLevel, phito) ;
												ON_DEBUG ( 0, 439 );	
p1(0) = p1(0) - COS(phito)*d;
												ON_DEBUG ( 0, 440 );	
p1(2) = p1(2) - SIN(phito)*d;
												ON_DEBUG ( 0, 441 );	
p1(1) = p1(1) - HeightAtPhi(nLevel, phito) ;
												ON_DEBUG ( 0, 443 );	
d = SQR(p1(0)*p1(0) + p1(2)*p1(2) + p1(2)*p1(2)) ;
												ON_DEBUG ( 0, 444 );	
return d;
												ON_DEBUG ( 0, 445 );
return 0;
}
// ----------------------------------------- // 
// Draw the racing track in a given range 
// ----------------------------------------- // 
// ------------------------ //
DGInt DrawTrackRange(DGInt nLevel, DGInt facwidth, DGInt phistart, DGInt phiend)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, nLevel);
ARGS_VAR(DGInt, facwidth);
ARGS_VAR(DGInt, phistart);
ARGS_VAR(DGInt, phiend);
												ON_DEBUG ( 0, 453 );
REGISTER_VAR_DEF(DGInt, sphi1, 0);
REGISTER_VAR_DEF(DGInt, sphi2, 0);
REGISTER_VAR_DEF(DGInt, cphi1, 0);
REGISTER_VAR_DEF(DGInt, cphi2, 0);
REGISTER_VAR_DEF(DGInt, d1, 0);
REGISTER_VAR_DEF(DGInt, d2, 0);
REGISTER_VAR_DEF(DGInt, h1, 0);
REGISTER_VAR_DEF(DGInt, h2, 0);
REGISTER_VAR_DEF(DGInt, tw1, 0);
REGISTER_VAR_DEF(DGInt, tw2, 0);
REGISTER_VAR_DEF(DGInt, bw, 0);
REGISTER_VAR_DEF(DGInt, hw, 0);
REGISTER_VAR_DEF(DGInt, phi, 0);
REGISTER_VAR_DEF(DGInt, delta, 0);
//	phiend = phiend + .3 // No gaps 
												ON_DEBUG ( 0, 456 );	
d1 = DistAtPhi(nLevel, phistart)/facwidth;
												ON_DEBUG ( 0, 457 );	
h1 = HeightAtPhi(nLevel, phistart)/facwidth;
												ON_DEBUG ( 0, 458 );	
tw1 = WidthAtPhi(nLevel, phistart)*facwidth;
												ON_DEBUG ( 0, 459 );	
mx1 = d1*COS(phistart) ;
												ON_DEBUG ( 0, 460 );	
my1 = d1*SIN(phistart) ;
												ON_DEBUG ( 0, 462 );	
bw=-DirAtPhi(nLevel, phistart) ;
												ON_DEBUG ( 0, 463 );	
cphi1 = COS(bw) ;
												ON_DEBUG ( 0, 464 );	
sphi1 = SIN(bw) ;
												ON_DEBUG ( 0, 466 );
delta = 5;
												ON_DEBUG ( 0, 467 );	
for (phi = phistart+delta ; ( delta)<0 ? ((phi)>=(phiend )) :((phi)<=(phiend )); phi+=( delta))
{
												ON_DEBUG ( 0, 468 );		
d2 = DistAtPhi(nLevel, phi)/facwidth;
												ON_DEBUG ( 0, 469 );		
h2 = HeightAtPhi(nLevel, phi)/facwidth;
												ON_DEBUG ( 0, 470 );		
tw2 = WidthAtPhi(nLevel, phi)*facwidth;
												ON_DEBUG ( 0, 471 );		
mx2 = d2*COS(phi) ;
												ON_DEBUG ( 0, 472 );		
my2 = d2*SIN(phi) ;
												ON_DEBUG ( 0, 474 );		
bw=-DirAtPhi(nLevel, phi) ;
												ON_DEBUG ( 0, 475 );		
cphi2 = COS(bw) ;
												ON_DEBUG ( 0, 476 );		
sphi2 = SIN(bw) ;
												ON_DEBUG ( 0, 478 );		
bw = 17;
												ON_DEBUG ( 0, 479 );		
hw = 12;
//  |\             /| 
//  | \___________/ | hw 
//  bw| tw  |  tw |bw 
// Leftmost plane 
												ON_DEBUG ( 0, 485 );		
X_OBJADDVERTEX( mx2+(-tw2-bw)*cphi2, h2+hw*2   , my2+(-tw2-bw)*sphi2, 0    , 1, RGB(255,255,255) );
												ON_DEBUG ( 0, 486 );		
X_OBJADDVERTEX( mx1+(-tw1-bw)*cphi1, h1+hw*2   , my1+(-tw1-bw)*sphi1, 0    , 0, RGB(255,255,255) );
												ON_DEBUG ( 0, 487 );		
X_OBJADDVERTEX( mx2+(-tw2-bw)*cphi2, h2+hw, my2+(-tw2-bw)*sphi2, 0.125, 1, RGB(255,255,255) );
												ON_DEBUG ( 0, 488 );		
X_OBJADDVERTEX( mx1+(-tw1-bw)*cphi1, h1+hw, my1+(-tw1-bw)*sphi1, 0.125, 0, RGB(255,255,255) );
// Left track border 
												ON_DEBUG ( 0, 491 );		
X_OBJADDVERTEX( mx2+(-tw2   )*cphi2, h2   , my2+(-tw2   )*sphi2, 0.25 , 1, RGB(255,255,255) );
												ON_DEBUG ( 0, 492 );		
X_OBJADDVERTEX( mx1+(-tw1   )*cphi1, h1   , my1+(-tw1   )*sphi1, 0.25 , 0, RGB(255,255,255) );
// Track 
												ON_DEBUG ( 0, 495 );		
X_OBJADDVERTEX( mx2+(tw2   )*cphi2, h2   , my2+(tw2   )*sphi2, 0.75 , 1, RGB(255,255,255) );
												ON_DEBUG ( 0, 496 );		
X_OBJADDVERTEX( mx1+(tw1   )*cphi1, h1   , my1+(tw1   )*sphi1, 0.75 , 0, RGB(255,255,255) );
// right track border 
												ON_DEBUG ( 0, 499 );		
X_OBJADDVERTEX( mx2+(tw2+bw)*cphi2, h2+hw, my2+(tw2+bw)*sphi2, 0.875, 1, RGB(255,255,255) );
												ON_DEBUG ( 0, 500 );		
X_OBJADDVERTEX( mx1+(tw1+bw)*cphi1, h1+hw, my1+(tw1+bw)*sphi1, 0.875, 0, RGB(255,255,255) );
// rightmost plane 
												ON_DEBUG ( 0, 503 );		
X_OBJADDVERTEX( mx2+(tw2+bw)*cphi2, h2+hw*2   , my2+(tw2+bw)*sphi2, 1    , 1, RGB(255,255,255) );
												ON_DEBUG ( 0, 504 );		
X_OBJADDVERTEX( mx1+(tw1+bw)*cphi1, h1+hw*2   , my1+(tw1+bw)*sphi1, 1    , 0, RGB(255,255,255) );
												ON_DEBUG ( 0, 505 );		
X_OBJNEWGROUP();
												ON_DEBUG ( 0, 506 );		
mx1=mx2;
												ON_DEBUG ( 0, 507 );		
my1=my2;
												ON_DEBUG ( 0, 508 );		
tw1=tw2;
												ON_DEBUG ( 0, 509 );		
h1= h2;
												ON_DEBUG ( 0, 510 );		
sphi1=sphi2;
												ON_DEBUG ( 0, 511 );		
cphi1=cphi2;
												ON_DEBUG ( 0, 512 );	
}
												ON_DEBUG ( 0, 513 );
return 0;
}
// ----------------------------------------- // 
// Draw the complete racing track 
// ----------------------------------------- // 
// ------------------------ //
DGInt PrepareTrackObjects(DGInt nLevel, DGInt facwidth)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, nLevel);
ARGS_VAR(DGInt, facwidth);
												ON_DEBUG ( 0, 522 );	
X_OBJSTART( 10);
												ON_DEBUG ( 0, 523 );	
DrawTrackRange (nLevel, facwidth, 0, 360) ;
												ON_DEBUG ( 0, 524 );	
X_OBJEND();
												ON_DEBUG ( 0, 525 );
return 0;
}
// ----------------------------------------- // 
// Keyboard input, acceleration and direction 
// ----------------------------------------- // 
// ------------------------ //
DGInt MovePlayer(DGInt nLevel, DGInt delta_time, DGInt phi)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, nLevel);
ARGS_VAR(DGInt, delta_time);
ARGS_VAR(DGInt, phi);
												ON_DEBUG ( 0, 533 );
REGISTER_VAR_DEF(DGInt, sx, 0);
REGISTER_VAR_DEF(DGInt, sy, 0);
REGISTER_VAR_DEF(DGInt, mx, 0);
REGISTER_VAR_DEF(DGInt, my, 0);
REGISTER_VAR_DEF(DGInt, b1, 0);
REGISTER_VAR_DEF(DGInt, b2, 0);
												ON_DEBUG ( 0, 534 );	
GETSCREENSIZE( sx, sy);
												ON_DEBUG ( 0, 535 );	
sx=sx/2;
												ON_DEBUG ( 0, 536 );	
MOUSESTATE( mx, my, b1, b2);
												ON_DEBUG ( 0, 537 );	
mx = (sx-mx)/sx;
												ON_DEBUG ( 0, 538 );	
if (mx<-1 )
mx=-1;
												ON_DEBUG ( 0, 539 );	
if (mx>1  )
mx=1;
												ON_DEBUG ( 0, 540 );	
delta_time=delta_time/360;
// millihours 
// Speed-Up/Slow Down 
// acc = Fmove - v*C_Roll) / mass; v=v0+dt*a; pos=pos+v*dt 
												ON_DEBUG ( 0, 543 );	
acc = MOUSEAXIS(3)*4 - ship_spd(0)*.07;
//lft=MOUSEAXIS(4)*400 
												ON_DEBUG ( 0, 545 );	
ship_spd(0) = ship_spd(0) + acc*delta_time;
												ON_DEBUG ( 0, 546 );	
if (MOUSEAXIS(4) )
{
												ON_DEBUG ( 0, 547 );	
lft=lft+GETTIMER()/100;
												ON_DEBUG ( 0, 548 );	
}
else
{
												ON_DEBUG ( 0, 549 );	
lft=lft-GETTIMER()/100;
												ON_DEBUG ( 0, 550 );	
}
												ON_DEBUG ( 0, 551 );	
if (lft<10 )
ship_spd(0)=0.5;
												ON_DEBUG ( 0, 552 );	
if (lft<0 )
lft=0;
												ON_DEBUG ( 0, 553 );	
if (lft>80 )
lft=80;
												ON_DEBUG ( 0, 554 );	
if (damage>100)
{
												ON_DEBUG ( 0, 555 );		
d=100;
												ON_DEBUG ( 0, 556 );		
WideScroller(CGStr("readme.txt")) ;
												ON_DEBUG ( 0, 557 );	 	
details(1) ;
												ON_DEBUG ( 0, 558 );	 
}
												ON_DEBUG ( 0, 559 );	 
if (KEY(01) )
start() ;
												ON_DEBUG ( 0, 560 );	
if (ship_spd(0)>25 )
ship_spd(0) = 25;
												ON_DEBUG ( 0, 561 );	
if (KEY(184) )
ship_spd(0)=35;
// Direction 
												ON_DEBUG ( 0, 564 );	
delta = mx*20/(ABS(ship_dir(0,2))*5+50) ;
// delta angle of front wheels 
												ON_DEBUG ( 0, 565 );	
if (delta!=0)
{
// Radius = L/sin(delta); L = distance of front->back wheels 
												ON_DEBUG ( 0, 567 );		
R = 5 / SIN(delta) ;
// omega = v / R 
												ON_DEBUG ( 0, 569 );		
ship_dir(0,2) = ship_spd(0) / R * 360;
// rad->deg 
// Limit radial velocity, since your stomach wouldn't let you do in 
// real life, either. 
												ON_DEBUG ( 0, 572 );		
if (ABS(ship_dir(0,2))>15)
{
												ON_DEBUG ( 0, 573 );			
if (ship_dir(0,2)<0)
{
ship_dir(0,2)=-15;
}
else
{
ship_dir(0,2)=15;
}
												ON_DEBUG ( 0, 574 );		
}
												ON_DEBUG ( 0, 575 );	
}
else
{
												ON_DEBUG ( 0, 576 );		
ship_dir(0,2)=0;
												ON_DEBUG ( 0, 577 );	
}
// add rotation and velocity 
												ON_DEBUG ( 0, 580 );	
ship_dir(0,0) = ship_dir(0,0) + ship_dir(0,2)*delta_time*2;
												ON_DEBUG ( 0, 581 );	
speed = ship_spd(0)*delta_time*10;
// Rotate+Move (X,Z) 
												ON_DEBUG ( 0, 584 );	
ship_pos(0,0) = ship_pos(0,0) + speed * SIN(ship_dir(0,0)) ;
												ON_DEBUG ( 0, 585 );	
ship_pos(0,2) = ship_pos(0,2) + speed * COS(ship_dir(0,0)) ;
// Up/down 
												ON_DEBUG ( 0, 588 );	
ship_pos(0,1) = HeightAtPhi(nLevel, phi) ;
//ship_pos[0][1] + speed * SIN(ship_dir[0][1]) 
												ON_DEBUG ( 0, 590 );
return 0;
}
// ----------------------------------------- // 
// Check collisions with the border 
// ----------------------------------------- // 
// ------------------------ //
DGInt CheckCollision(DGInt nLevel, DGInt phi, DGInt max_mean)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, nLevel);
ARGS_VAR(DGInt, phi);
ARGS_VAR(DGInt, max_mean);
												ON_DEBUG ( 0, 597 );	
REGISTER_VAR_DEF(DGInt, dist, 0);
REGISTER_VAR_DEF(DGInt, dist2, 0);
REGISTER_VAR_DEF(DGInt, tw, 0);
REGISTER_VAR_DEF(DGInt, h, 0);
REGISTER_VAR_DEF(DGInt, phi_new, 0);
REGISTER_VAR_DEF(DGInt, mx, 0);
REGISTER_VAR_DEF(DGInt, my, 0);
												ON_DEBUG ( 0, 599 );	
dist2=1000000;
												ON_DEBUG ( 0, 600 );	
phi_new = phi;
												ON_DEBUG ( 0, 601 );	
for (dphi = phi-8 ; ( .5)<0 ? ((dphi)>=(phi+8 )) :((dphi)<=(phi+8 )); dphi+=( .5))
{
// Get closest point to racing track 
												ON_DEBUG ( 0, 603 );		
dist = DistAtPhi(nLevel, dphi) ;
												ON_DEBUG ( 0, 604 );		
mx = dist*COS(dphi) - ship_pos(0,0) ;
												ON_DEBUG ( 0, 605 );		
my = dist*SIN(dphi) - ship_pos(0,2) ;
												ON_DEBUG ( 0, 606 );		
dist = SQR(mx*mx + my*my) ;
												ON_DEBUG ( 0, 607 );		
if (dist<dist2)
{
												ON_DEBUG ( 0, 608 );			
dist2=dist;
												ON_DEBUG ( 0, 609 );			
phi_new = dphi;
												ON_DEBUG ( 0, 610 );		
}
												ON_DEBUG ( 0, 611 );	
}
												ON_DEBUG ( 0, 612 );	
phi = phi_new;
												ON_DEBUG ( 0, 614 );	
tw = WidthAtPhi(nLevel, phi) ;
												ON_DEBUG ( 0, 615 );	
if (dist2>tw)
{
// Crashed to border 
// Which side? 
												ON_DEBUG ( 0, 617 );		
dist = DistAtPhi(nLevel, phi) ;
												ON_DEBUG ( 0, 619 );		
dist2 = SQR (ship_pos(0,2) * ship_pos(0,2) + ship_pos(0,0) * ship_pos(0,0)) ;
												ON_DEBUG ( 0, 620 );		
phi_new = DirAtPhi(nLevel, phi) ;
// ATAN(DistAtPhi(nLevel, phi+.1)-dist, TAN(.1) * dist) - phi 
// Outer bounds 
												ON_DEBUG ( 0, 623 );		
if (dist2 > dist+tw)
{
// dist+tw-2 
												ON_DEBUG ( 0, 624 );			
ship_pos(0,0) = dist*COS(phi) + tw*COS(-phi_new) ;
												ON_DEBUG ( 0, 625 );			
ship_pos(0,2) = dist*SIN(phi) + tw*SIN(-phi_new) ;
												ON_DEBUG ( 0, 626 );			
ship_dir(0,0) = phi_new-3;
//	ship_dir[0][2] = 0 
												ON_DEBUG ( 0, 628 );			
ship_spd(0) = ship_spd(0) * .5;
												ON_DEBUG ( 0, 629 );			
damage=damage+0.01;
												ON_DEBUG ( 0, 630 );		
}
// Inner bounds 
												ON_DEBUG ( 0, 632 );		
if (dist2 < dist-tw)
{
												ON_DEBUG ( 0, 633 );			
ship_pos(0,0) = dist*COS(phi) - tw*COS(-phi_new) ;
												ON_DEBUG ( 0, 634 );			
ship_pos(0,2) = dist*SIN(phi) - tw*SIN(-phi_new) ;
												ON_DEBUG ( 0, 635 );			
ship_dir(0,0) = phi_new+1;
//	ship_dir[0][2] = 0 
												ON_DEBUG ( 0, 637 );			
ship_spd(0) = ship_spd(0) * .5;
												ON_DEBUG ( 0, 638 );			
damage=damage+0.01;
												ON_DEBUG ( 0, 639 );		
}
// Too far out 
//IF ABS(dist2 - dist) > tw + 3 
//	ship_pos[0][0] = dist * COS(phi) 
//	ship_pos[0][2] = dist * SIN(phi) 
//	ship_spd[0] = 0 
//		ship_dir[0][0] = phi_new // -phi-2//ship_dir[0]-1 
//		ENDIF 
												ON_DEBUG ( 0, 648 );	
}
// Crash with enemy 
												ON_DEBUG ( 0, 651 );	
for (n = 0 ; n<= max_mean; n++)
{
												ON_DEBUG ( 0, 652 );		
mx = mean_pos(n,0)-ship_pos(0,0) ;
												ON_DEBUG ( 0, 653 );		
my = mean_pos(n,2)-ship_pos(0,2) ;
												ON_DEBUG ( 0, 654 );		
if (mx*mx+my*my < 3000 AND KEY(57) )
{
												ON_DEBUG ( 0, 655 );		
PLAYSOUND(3,0,1) ;
												ON_DEBUG ( 0, 656 );			
ship_spd(0)=ship_spd(0)*0.2;
												ON_DEBUG ( 0, 657 );			
max_means=max_means-1;
												ON_DEBUG ( 0, 658 );			
score=score+1;
												ON_DEBUG ( 0, 659 );			
blast() ;
												ON_DEBUG ( 0, 660 );		
}
												ON_DEBUG ( 0, 661 );		
if (mx*mx+my*my > 3000 AND mx*mx+my*my < 5000)
{
												ON_DEBUG ( 0, 662 );		
chk=PLAYSOUND (5,0,1) ;
												ON_DEBUG ( 0, 663 );			
damage=damage+0.0001;
												ON_DEBUG ( 0, 664 );		
}
												ON_DEBUG ( 0, 665 );	
}
												ON_DEBUG ( 0, 667 );	
return phi;
												ON_DEBUG ( 0, 668 );
return 0;
}
// ------------------------ //
DGInt MoveMeans(DGInt nLevel, DGInt delta_time, DGInt max_mean)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, nLevel);
ARGS_VAR(DGInt, delta_time);
ARGS_VAR(DGInt, max_mean);
												ON_DEBUG ( 0, 672 );	
REGISTER_VAR_DEF(DGInt, n, 0);
REGISTER_VAR_DEF(DGInt, d, 0);
REGISTER_VAR_DEF(DGInt, p, 0);
REGISTER_VAR_DEF(DGInt, b, 0);
												ON_DEBUG ( 0, 674 );	
for (n = 0 ; n<= max_mean; n++)
{
												ON_DEBUG ( 0, 675 );		
mean_phi(n) = mean_phi(n) + (.005+(.0008*(n+8))) * delta_time;
												ON_DEBUG ( 0, 676 );		
if (mean_phi(n)>360 )
mean_phi(n)=mean_phi(n)-360;
												ON_DEBUG ( 0, 677 );		
p = mean_phi(n) ;
												ON_DEBUG ( 0, 678 );		
d = DistAtPhi(nLevel, p) ;
												ON_DEBUG ( 0, 679 );		
b = .7*WidthAtPhi(nLevel, p) ;
												ON_DEBUG ( 0, 680 );		
// select:
if (FALSE){
												ON_DEBUG ( 0, 681 );		
} else if( (mean_typ(n) ) == (0) ){// mittig 
												ON_DEBUG ( 0, 682 );			
mean_pos(n,0) = COS(p) * d;
												ON_DEBUG ( 0, 683 );			
mean_pos(n,2) = SIN(p) * d;
												ON_DEBUG ( 0, 684 );		
} else if( (mean_typ(n) ) == (1) ){// Links 
												ON_DEBUG ( 0, 685 );			
mean_pos(n,0) = COS(p) * (d+b) ;
												ON_DEBUG ( 0, 686 );			
mean_pos(n,2) = SIN(p) * (d+b) ;
												ON_DEBUG ( 0, 688 );		
} else if( (mean_typ(n) ) == (2) ){// rechts 
												ON_DEBUG ( 0, 689 );			
mean_pos(n,0) = COS(p) * (d-b) ;
												ON_DEBUG ( 0, 690 );			
mean_pos(n,2) = SIN(p) * (d-b) ;
												ON_DEBUG ( 0, 692 );		
} else if( (mean_typ(n) ) == (3) ){// ZigZag 
												ON_DEBUG ( 0, 693 );			
b = b * SIN(p*8) ;
												ON_DEBUG ( 0, 694 );			
mean_pos(n,0) = COS(p) * (d+b) ;
												ON_DEBUG ( 0, 695 );			
mean_pos(n,2) = SIN(p) * (d+b) ;
												ON_DEBUG ( 0, 696 );		
}
												ON_DEBUG ( 0, 698 );		
mean_pos(n,1) = HeightAtPhi(nLevel, p) ;
												ON_DEBUG ( 0, 699 );	
}
												ON_DEBUG ( 0, 700 );
return 0;
}
// ------------------------ //
DGInt ShowMeans(DGInt nLevel, DGInt max_mean)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, nLevel);
ARGS_VAR(DGInt, max_mean);
												ON_DEBUG ( 0, 703 );	
X_SCALING( 3, 3, 3);
												ON_DEBUG ( 0, 704 );	
for (n = 0 ; n<= max_mean; n++)
{
												ON_DEBUG ( 0, 705 );		
X_CULLMODE( 1);
												ON_DEBUG ( 0, 706 );		
X_SETTEXTURE( 2,-1);
												ON_DEBUG ( 0, 707 );		
X_SCALING( 50,50,50);
												ON_DEBUG ( 0, 708 );		
X_MOVEMENT( mean_pos(n,0), mean_pos(n,1)+9, mean_pos(n,2) );
												ON_DEBUG ( 0, 709 );		
X_ROTATION( DirAtPhi(nLevel, mean_phi(n)), 0,1,0);
												ON_DEBUG ( 0, 711 );		
X_DRAWOBJ( 16, 0);
// Flame 
												ON_DEBUG ( 0, 714 );		
X_CULLMODE( 0);
												ON_DEBUG ( 0, 715 );		
ALPHAMODE( 1);
												ON_DEBUG ( 0, 716 );		
X_SCALING( 4,4,4);
												ON_DEBUG ( 0, 717 );		
X_ROTATION( ship_dir(0,0)+180, 0, 1, 0);
												ON_DEBUG ( 0, 718 );		
X_DRAWOBJ( 11,0);
// Shadow 
												ON_DEBUG ( 0, 721 );		
X_CULLMODE( 1);
												ON_DEBUG ( 0, 722 );		
X_SETTEXTURE( 9,-1);
												ON_DEBUG ( 0, 723 );		
X_MOVEMENT( mean_pos(n,0), mean_pos(n,1), mean_pos(n,2) );
												ON_DEBUG ( 0, 724 );		
X_ROTATION( DirAtPhi(nLevel, mean_phi(n))+90, 0,1,0);
												ON_DEBUG ( 0, 726 );		
ALPHAMODE( -.1);
												ON_DEBUG ( 0, 727 );		
X_DRAWOBJ( 16, 0);
												ON_DEBUG ( 0, 728 );		
ALPHAMODE( 0);
												ON_DEBUG ( 0, 730 );	
}
												ON_DEBUG ( 0, 731 );
return 0;
}
// ------------------------ //
DGInt StageSelect()
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
												ON_DEBUG ( 0, 735 );
g_Level=1;
												ON_DEBUG ( 0, 736 );
REGISTER_VAR_DEF(DGInt, p, 0);
REGISTER_VAR_DEF(DGInt, h, 0);
REGISTER_VAR_DEF(DGInt, h2, 0);
												ON_DEBUG ( 0, 737 );	
p=0;
												ON_DEBUG ( 0, 738 );	
Statusbar(.5) ;
												ON_DEBUG ( 0, 739 );	
PrepareTrackObjects(g_Level, 2) ;
												ON_DEBUG ( 0, 740 );	
Statusbar(1) ;
												ON_DEBUG ( 0, 741 );	
while( TRUE)
{
												ON_DEBUG ( 0, 742 );		
if (KEY(203) OR KEY(205) OR MOUSEAXIS(4) )
{
												ON_DEBUG ( 0, 743 );			
if (KEY(203)                 )
g_Level=g_Level-1;
												ON_DEBUG ( 0, 744 );			
if (KEY(205) OR MOUSEAXIS(4) )
g_Level=g_Level+1;
												ON_DEBUG ( 0, 745 );			
if (g_Level>3 )
g_Level=1;
												ON_DEBUG ( 0, 746 );			
if (g_Level<1 )
g_Level=3;
												ON_DEBUG ( 0, 747 );			
while( KEY(203) OR KEY(205) OR MOUSEAXIS(4))
{
}
												ON_DEBUG ( 0, 748 );			
Statusbar(.5) ;
												ON_DEBUG ( 0, 749 );			
PrepareTrackObjects(g_Level, 2) ;
												ON_DEBUG ( 0, 750 );			
Statusbar(1) ;
												ON_DEBUG ( 0, 751 );		
}
												ON_DEBUG ( 0, 752 );		
if (KEY(200) OR  KEY(57) OR MOUSEAXIS(3) )
goto skip;
												ON_DEBUG ( 0, 753 );		
p=p+1;
												ON_DEBUG ( 0, 754 );		
if (p>360 )
p=p-360;
												ON_DEBUG ( 0, 755 );		
X_MAKE3D( 1, 4000, 45);
												ON_DEBUG ( 0, 756 );		
X_CAMERA( 0, 400, -1500,    0,0,0);
// Overview of all 
												ON_DEBUG ( 0, 757 );		
X_MIPMAPPING( TRUE);
												ON_DEBUG ( 0, 758 );		
X_MOVEMENT( 0,0,0);
												ON_DEBUG ( 0, 759 );		
X_SCALING( .5,.5,.5);
												ON_DEBUG ( 0, 760 );		
X_ROTATION( p, 0, 1, 0);
												ON_DEBUG ( 0, 761 );		
X_SETTEXTURE( 0,-1);
												ON_DEBUG ( 0, 762 );		
X_DRAWOBJ( 10, 0);
												ON_DEBUG ( 0, 763 );		
ALPHAMODE( .5);
												ON_DEBUG ( 0, 764 );		
X_SETTEXTURE( 13,-1);
												ON_DEBUG ( 0, 765 );		
X_MOVEMENT( 0,-30,0);
												ON_DEBUG ( 0, 766 );		
X_SCALING( 300, 300, 300);
												ON_DEBUG ( 0, 767 );		
X_DRAWOBJ( 13, 0);
												ON_DEBUG ( 0, 769 );		
ALPHAMODE( -1);
												ON_DEBUG ( 0, 770 );		
X_MAKE2D();
												ON_DEBUG ( 0, 771 );		
for (i = 0 ; i<= 640; i++)
{
												ON_DEBUG ( 0, 772 );			
h = DistAtPhi(g_Level, i/16*9)*.2;
												ON_DEBUG ( 0, 773 );			
h2 = DistAtPhi(g_Level, (i+1)/16*9)*.2;
												ON_DEBUG ( 0, 774 );			
DRAWLINE( i, h, i+1, h2, RGB(128 ,255, 128) );
												ON_DEBUG ( 0, 775 );			
DRAWLINE( i, h2, i+1, h+1, RGB(128 ,255, 128) );
												ON_DEBUG ( 0, 776 );		
}
												ON_DEBUG ( 0, 777 );		
ALPHAMODE( 0);
												ON_DEBUG ( 0, 778 );		
PRINT( CGStr("Select Stage - ") + g_Level, 0, 0);
												ON_DEBUG ( 0, 779 );		
ALPHAMODE( 1);
												ON_DEBUG ( 0, 780 );		 
AnyScroller(CGStr("                                    use Arrow keys to choose level, press space to select.         press space to select")) ;
												ON_DEBUG ( 0, 781 );		
SHOWSCREEN();
												ON_DEBUG ( 0, 782 );	
}
												ON_DEBUG ( 0, 783 );
skip:;
												ON_DEBUG ( 0, 784 );	
return g_Level;
												ON_DEBUG ( 0, 785 );
return 0;
}
// ------------------------ //
DGInt maximum(DGInt a, DGInt b)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, a);
ARGS_VAR(DGInt, b);
												ON_DEBUG ( 0, 789 );	
if (a>b )
return a;
												ON_DEBUG ( 0, 790 );	
return b;
												ON_DEBUG ( 0, 791 );
return 0;
}
// ------------------------ //
DGInt minimum(DGInt a, DGInt b)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, a);
ARGS_VAR(DGInt, b);
												ON_DEBUG ( 0, 794 );	
if (a<b )
return a;
												ON_DEBUG ( 0, 795 );	
return b;
												ON_DEBUG ( 0, 796 );
return 0;
}
// ------------------------------------------------------------- // 
//   --- ANYSCROLLER --- 
// ------------------------------------------------------------- // 
// ------------------------ //
DGInt AnyScroller(DGStr globtext_Str)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGStr, globtext_Str);
// Scroller 
												ON_DEBUG ( 0, 805 );
REGISTER_VAR_DEF(DGInt, fx, 0);
REGISTER_VAR_DEF(DGInt, fy, 0);
												ON_DEBUG ( 0, 806 );	
GETFONTSIZE( fx, fy);
												ON_DEBUG ( 0, 807 );		
scrx=scrx-2;
if (scrx<=0)
{
scrx=fx;
glchr=glchr+1;
if (glchr>LEN(globtext_Str)+40 )
glchr=0;
}
												ON_DEBUG ( 0, 808 );		
for (glnum = -1 ; glnum<= 800/fx; glnum++)
{
												ON_DEBUG ( 0, 809 );			
glstr_Str= MID_Str(globtext_Str, glnum+glchr, 1) ;
												ON_DEBUG ( 0, 810 );			
PRINT( glstr_Str, (glnum*fx)+scrx, 400);
												ON_DEBUG ( 0, 811 );		
}
												ON_DEBUG ( 0, 812 );
return 0;
}
// ANYSCROLLER 
// ------------------------ //
DGInt Statusbar(DGInt percent)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, percent);
												ON_DEBUG ( 0, 815 );	
FILLRECT( 0, screeny/2-fnty, screenx-1, screeny/2+fnty, RGB(255,255,255) );
												ON_DEBUG ( 0, 816 );	
FILLRECT( 1+percent*(screenx-2), screeny/2-fnty, screenx-1, screeny/2+fnty, RGB(0,0,255) );
												ON_DEBUG ( 0, 817 );	
PRINT( INTEGER(percent*100), screenx/2-fntx*2, screeny/2+fnty);
												ON_DEBUG ( 0, 818 );	
SHOWSCREEN();
												ON_DEBUG ( 0, 819 );
return 0;
}
// ------------------------ //
DGInt fire()
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
//fire 
												ON_DEBUG ( 0, 823 );	
PLAYSOUND(2,0,1) ;
												ON_DEBUG ( 0, 824 );	
X_SPOT_LT( -2, RGB(255,255,255), ship_pos(0,0)+30, ship_pos(0,1)+8+lft, ship_pos(0,2),ship_pos(0,0)+30, ship_pos(0,1), ship_pos(0,2),0);
												ON_DEBUG ( 0, 825 );	
X_LINE( ship_pos(0,0)+30, ship_pos(0,1)+8+lft, ship_pos(0,2),ship_pos(0,0)+30, ship_pos(0,1), ship_pos(0,2),5,RGB(255,2,2) );
												ON_DEBUG ( 0, 826 );	
return 0; // RETURN f. SUB
												ON_DEBUG ( 0, 827 );
return 0;
}
// ------------------------ //
DGInt WideScroller(DGStr filename_Str)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGStr, filename_Str);
// Diese Variablen sind als LOCAL definiert: 
// filename$ 
												ON_DEBUG ( 0, 833 );	
REGISTER_VAR(DGStrArray, text_Str);
REGISTER_VAR(DGStr, a_Str);
REGISTER_VAR_DEF(DGInt, maxline, 0);
REGISTER_VAR_DEF(DGInt, z, 0);
REGISTER_VAR_DEF(DGInt, dz, 0);
REGISTER_VAR_DEF(DGInt, dx, 0);
REGISTER_VAR_DEF(DGInt, y, 0);
REGISTER_VAR_DEF(DGInt, fx, 0);
REGISTER_VAR_DEF(DGInt, fy, 0);
												ON_DEBUG ( 0, 834 );	
DIM(text_Str, 256);
												ON_DEBUG ( 0, 836 );	
GETFONTSIZE( fx, fy);
// Neuer, guter Befehl / New and good command (24.10.01) 
												ON_DEBUG ( 0, 838 );	
fy=fy+8;
// Platz lassen / Leave space 
												ON_DEBUG ( 0, 840 );	
for (i = 0 ; i<= 255; i++)
{
												ON_DEBUG ( 0, 841 );		
GETFILE( filename_Str, i, a_Str );
												ON_DEBUG ( 0, 842 );		
if (a_Str==CGStr("NO_FILE") )
return 0; // RETURN f. SUB
												ON_DEBUG ( 0, 843 );		
if (a_Str==CGStr("NO_DATA") )
goto skip;
												ON_DEBUG ( 0, 844 );		
text_Str(i)=a_Str ;
												ON_DEBUG ( 0, 845 );		
maxline=maxline+1;
												ON_DEBUG ( 0, 846 );	
}
												ON_DEBUG ( 0, 848 );	
skip:;
												ON_DEBUG ( 0, 851 );	
for (zt = 480 ; ( -1)<0 ? ((zt)>=(0-maxline*fy )) :((zt)<=(0-maxline*fy )); zt+=( -1))
{
// Aufw�rts / Move upwards 
												ON_DEBUG ( 0, 852 );		
for (z = 0 ; z<= maxline-1; z++)
{
												ON_DEBUG ( 0, 853 );			
dz=z*20+zt;
												ON_DEBUG ( 0, 854 );			
dx=(640-LEN(text_Str(z))*fx)/2;
												ON_DEBUG ( 0, 855 );			
if (dz<480 AND dz>-20 )
PRINT( text_Str(z), dx, dz);
												ON_DEBUG ( 0, 856 );		
}
												ON_DEBUG ( 0, 857 );		
SHOWSCREEN();
												ON_DEBUG ( 0, 858 );		
if (KEY(57) OR KEY(28) )
return 0; // RETURN f. SUB
												ON_DEBUG ( 0, 859 );	
}
												ON_DEBUG ( 0, 860 );
return 0;
}
// WIDESCROLLER 
// ------------------------ //
DGInt start()
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
												ON_DEBUG ( 0, 863 );
PLAYMUSIC( CGStr("Data/intro.mid") );
												ON_DEBUG ( 0, 864 );
BLENDSCREEN( CGStr("Data/start.bmp") );
												ON_DEBUG ( 0, 865 );
while( TRUE)
{
												ON_DEBUG ( 0, 866 );
X_AUTONORMALS( 2);
												ON_DEBUG ( 0, 867 );	
phi=phi+GETTIMER()/20;
if (phi>=360 )
phi=phi-360;
												ON_DEBUG ( 0, 868 );	
SPRITE( 18,0,0);
												ON_DEBUG ( 0, 869 );	
ALPHAMODE( -1);
												ON_DEBUG ( 0, 870 );	
AnyScroller(CGStr("                   press space to start. F1---About")) ;
												ON_DEBUG ( 0, 871 );	
rpt:;
												ON_DEBUG ( 0, 872 );	
if (KEY(59) )
d1=1;
												ON_DEBUG ( 0, 873 );	
if (d1==1)
{
												ON_DEBUG ( 0, 874 );			 
WideScroller(CGStr("readme.txt")) ;
												ON_DEBUG ( 0, 875 );		 	 
d1=0;
												ON_DEBUG ( 0, 876 );	 
}
												ON_DEBUG ( 0, 877 );
if (KEY(57) )
goto skip;
												ON_DEBUG ( 0, 878 );	
X_MAKE3D( 1,1000,45);
												ON_DEBUG ( 0, 879 );	
X_CAMERA( 20,3,7,  0,3,0);
												ON_DEBUG ( 0, 880 );	
X_AMBIENT_LT( 0,RGB(255,255,255) );
												ON_DEBUG ( 0, 881 );	
X_SCALING( 0.4,0.4,0.4);
												ON_DEBUG ( 0, 882 );	
X_SETTEXTURE( 2,-1);
												ON_DEBUG ( 0, 883 );	
X_SPOT_LT( -2,RGB(200,2,124),0,0,0,0,3,0,0);
//	X_ROTATION 180, 0,1,0 
												ON_DEBUG ( 0, 886 );	
X_ROTATION( phi, 0,1,0);
												ON_DEBUG ( 0, 887 );	
X_DRAWOBJ( 1,0);
												ON_DEBUG ( 0, 889 );	
SHOWSCREEN();
												ON_DEBUG ( 0, 890 );	
HUSH();
												ON_DEBUG ( 0, 891 );
}
												ON_DEBUG ( 0, 892 );
BLACKSCREEN();
												ON_DEBUG ( 0, 893 );
skip:;
												ON_DEBUG ( 0, 894 );
details(0) ;
												ON_DEBUG ( 0, 895 );
BLACKSCREEN();
												ON_DEBUG ( 0, 896 );
return 0; // RETURN f. SUB
												ON_DEBUG ( 0, 897 );
return 0;
}
// ------------------------ //
DGInt details(DGInt f)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, f);
												ON_DEBUG ( 0, 901 );
while( TRUE)
{
												ON_DEBUG ( 0, 902 );
SPRITE( 19,0,0);
												ON_DEBUG ( 0, 903 );
if (f==1 )
PLAYSOUND(4,0,1) ;
												ON_DEBUG ( 0, 904 );		
if (KEY(28) )
goto skip1;
												ON_DEBUG ( 0, 905 );	
PRINT( name_Str,346,126);
												ON_DEBUG ( 0, 906 );	
PRINT( inst_Str,349,204);
												ON_DEBUG ( 0, 907 );	
PRINT( score*100, 108,363);
												ON_DEBUG ( 0, 908 );	
SHOWSCREEN();
												ON_DEBUG ( 0, 909 );	
}
												ON_DEBUG ( 0, 910 );	
skip1:;
												ON_DEBUG ( 0, 911 );	
if (f==1 )
WideScroller(CGStr("over.txt")) ;
												ON_DEBUG ( 0, 912 );	
return name_Str ;
												ON_DEBUG ( 0, 913 );	
BLACKSCREEN();
												ON_DEBUG ( 0, 914 );
return 0;
}
// ------------------------ //
DGInt blast()
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
												ON_DEBUG ( 0, 918 );
blst=500;
												ON_DEBUG ( 0, 919 );		
X_AMBIENT_LT( 0,RGB(255,0,0) );
												ON_DEBUG ( 0, 920 );		
X_CULLMODE( 0);
												ON_DEBUG ( 0, 921 );		
ALPHAMODE( 1);
												ON_DEBUG ( 0, 922 );		
X_SCALING( 4,4,4*blst);
												ON_DEBUG ( 0, 923 );		
X_MOVEMENT( mean_pos(n,0), mean_pos(n,1)+9, mean_pos(n,2) );
												ON_DEBUG ( 0, 924 );		
X_ROTATION( ship_dir(0,0)+180, 0, 1, 0);
												ON_DEBUG ( 0, 925 );		
X_DRAWOBJ( 11,0);
												ON_DEBUG ( 0, 927 );
return 0;
}
// ------------------------ //
DGInt attack()
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
												ON_DEBUG ( 0, 930 );	
p=RND(1) ;
												ON_DEBUG ( 0, 931 );	
X_LINE( ship_pos(0,0)+30/p*2, ship_pos(0,1)+8+lft, ship_pos(0,2)+19/p*2,ship_pos(0,0), ship_pos(0,1), ship_pos(0,2),5,RGB(2,255,2) );
												ON_DEBUG ( 0, 933 );
return 0;
}
// ------------------------ //
DGInt __end_main__foo__()
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
return 0;
}
} // namespace
using namespace __GLBASIC__;
// Entry Point
int APIENTRY WinMain(HINSTANCE hInst, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
__DG_RESX=800;
__DG_RESY=600;
__g_cmdline.Assign(lpCmdLine);
__DG_FULLSCREEN=0;
__DG_FRAMERATE=-1;
__DG_DEBUG=1;
__DG_WANTMOUSE=1;
__DG_SCHOOLVER=0;
__GlobalInit(hInst, hPrevInstance, __g_cmdline.GetStrData(), nCmdShow, "Falcon chase");
__g_debugline=__g_error=__g_errorline=0;
__MainGameSub_();
__EndProgram(); return 0;
}
#ifdef LINUX
int main(int argc, char* argv[]){for (long nc=0; nc<argc; nc++){__g_cmdline+=argv[nc];__g_cmdline+=" ";}WinMain(NULL, NULL, (char*)__g_cmdline.c_str(), 0);}
#endif
