#include "gpc_temp.h"
namespace __GLBASIC__{
/* GBAS: E:\newf\cese\tools\TruckDriver\CityControl.gbas */
// --------------------------------- // 
// Project: TruckDriver - CityControl 
// Start: Saturday, March 20, 2004 
// IDE Version: 1.40316 
// Road Corners: No Road at: 
//  1 
// 204 
//  8 
// city-dim: 
// 0-15: Road 
// 16:   Grass/Slowdown 
// 50:   Shop 
// 55+:  Solid Objects 
//       55 - tree 
//       56 - shop house 
// Colision-bits: 
// 1:Wall 
// 2:Slow 
// ------------------------------------------------------------- // 
// -=#  LOADLEVEL  #=- 
// ------------------------------------------------------------- // 
// ------------------------ //
DGInt LoadLevel(DGInt num)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, num);
// Diese Variablen sind als LOCAL definiert: 
// num 
												ON_DEBUG ( 2, 28 );
REGISTER_VAR_DEF(DGInt, x, 0);
REGISTER_VAR_DEF(DGInt, y, 0);
REGISTER_VAR(DGStr, line_Str);
REGISTER_VAR(DGStr, wd_Str);
												ON_DEBUG ( 2, 29 );	
DIM(city, 40,40);
												ON_DEBUG ( 2, 30 );	
line_Str=CGStr("") ;
												ON_DEBUG ( 2, 31 );	
for (y = 0 ; y<= 39; y++)
{
												ON_DEBUG ( 2, 32 );		
GETFILE( CGStr("city")+num+CGStr(".txt"), y, line_Str );
												ON_DEBUG ( 2, 33 );		
for (x = 0 ; x<= 39; x++)
{
												ON_DEBUG ( 2, 34 );			
wd_Str = MID_Str(line_Str, x, 1) ;
												ON_DEBUG ( 2, 35 );			
// select:
if (FALSE){
												ON_DEBUG ( 2, 36 );				
} else if( (wd_Str ) == (CGStr("#")) ){city(x,y)=16;
// Gras 
												ON_DEBUG ( 2, 37 );				
} else if( (wd_Str ) == (CGStr(" ")) ){city(x,y)= 0;
// Road 
												ON_DEBUG ( 2, 38 );				
} else if( (wd_Str ) == (CGStr("A")) ){city(x,y)=55;
// Tree 
												ON_DEBUG ( 2, 39 );				
} else if( (wd_Str ) == (CGStr("S")) ){city(x,y)=50;
// Shop 
												ON_DEBUG ( 2, 40 );				
} else if( (wd_Str ) == (CGStr("L")) ){city(x,y)=56;
// Shop-House 
												ON_DEBUG ( 2, 41 );			
}
												ON_DEBUG ( 2, 42 );		
}
												ON_DEBUG ( 2, 43 );	
}
// Preparing road curves 
												ON_DEBUG ( 2, 46 );	
for (y = 0 ; y<= 39; y++)
{
												ON_DEBUG ( 2, 47 );		
for (x = 0 ; x<= 39; x++)
{
												ON_DEBUG ( 2, 48 );			
if (city(x,y)==0)
{
												ON_DEBUG ( 2, 49 );				
num=0;
												ON_DEBUG ( 2, 50 );				
if (y>0  AND city(x,y-1)>15 )
num=num+1;
												ON_DEBUG ( 2, 51 );				
if (x>0  AND city(x-1,y)>15 )
num=num+2;
												ON_DEBUG ( 2, 52 );				
if (y<39 AND city(x,y+1)>15 )
num=num+8;
												ON_DEBUG ( 2, 53 );				
if (x<39 AND city(x+1,y)>15 )
num=num+4;
												ON_DEBUG ( 2, 54 );				
city(x,y) = num;
												ON_DEBUG ( 2, 55 );			
}
												ON_DEBUG ( 2, 56 );		
}
												ON_DEBUG ( 2, 57 );	
}
												ON_DEBUG ( 2, 58 );
return 0;
}
// LOADLEVEL 
// ------------------------------------------------------------- // 
// -=#  LOADTEXTURES  #=- 
// ------------------------------------------------------------- // 
// ------------------------ //
DGInt LoadTextures(void){
#undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
												ON_DEBUG ( 2, 67 );
REGISTER_VAR_DEF(DGInt, i, 0);
REGISTER_VAR_DEF(DGInt, c, 0);
REGISTER_VAR_DEF(DGInt, m, 0);
												ON_DEBUG ( 2, 68 );	
for (i = 0 ; i<= 15; i++)
{
LOADSPRITE( CGStr("track")+i+CGStr(".bmp"), i);
}
												ON_DEBUG ( 2, 69 );	
LOADSPRITE( CGStr("grass0.bmp"), 16);
												ON_DEBUG ( 2, 70 );	
LOADSPRITE( CGStr("shop.bmp"), 50);
												ON_DEBUG ( 2, 71 );	
LOADSPRITE( CGStr("tree.bmp"), 55);
												ON_DEBUG ( 2, 73 );	
c=RGB(0xff, 0xff, 0xff) ;
												ON_DEBUG ( 2, 74 );	
i=GLOBAL TileSize;
												ON_DEBUG ( 2, 75 );	
i = i/64*64.75;
// one pixel overlapping 
												ON_DEBUG ( 2, 76 );	
X_OBJSTART( 0);
												ON_DEBUG ( 2, 77 );		
X_OBJADDVERTEX( 0,0,0,0,0,c);
												ON_DEBUG ( 2, 78 );		
X_OBJADDVERTEX( i,0,0,1,0,c);
												ON_DEBUG ( 2, 79 );		
X_OBJADDVERTEX( 0,0,i,0,1,c);
												ON_DEBUG ( 2, 80 );		
X_OBJADDVERTEX( i,0,i,1,1,c);
												ON_DEBUG ( 2, 81 );	
X_OBJEND();
												ON_DEBUG ( 2, 83 );	
X_LOADOBJ(  CGStr("shop1.ddd"), 56);
												ON_DEBUG ( 2, 84 );	
LOADSPRITE( CGStr("shop1.bmp"), 56);
//X_LOADOBJ " 
												ON_DEBUG ( 2, 87 );
return 0;
}
// LOADTEXTURES 
// ------------------------------------------------------------- // 
// -=#  DRAWCITY  #=- 
// ------------------------------------------------------------- // 
// ------------------------ //
DGInt DrawCity(DGInt px, DGInt py, DGInt radius)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, px);
ARGS_VAR(DGInt, py);
ARGS_VAR(DGInt, radius);
// Diese Variablen sind als LOCAL definiert: 
// px, py, radius 
												ON_DEBUG ( 2, 96 );
REGISTER_VAR_DEF(DGInt, x, 0);
REGISTER_VAR_DEF(DGInt, y, 0);
REGISTER_VAR_DEF(DGInt, dx, 0);
REGISTER_VAR_DEF(DGInt, dy, 0);
REGISTER_VAR_DEF(DGInt, num, 0);
												ON_DEBUG ( 2, 97 );	
sz = 3.0;
// Size of one tile 
												ON_DEBUG ( 2, 98 );	
radius=radius/GLOBAL TileSize;
												ON_DEBUG ( 2, 99 );	
px=px/GLOBAL TileSize;
												ON_DEBUG ( 2, 100 );	
py=py/GLOBAL TileSize;
												ON_DEBUG ( 2, 101 );	
radius=radius*radius;
// Make a 'green lawn' background 
												ON_DEBUG ( 2, 103 );	
X_SCALING( 1000,1000,1000);
												ON_DEBUG ( 2, 104 );	
X_MOVEMENT( -500,-10,-500);
												ON_DEBUG ( 2, 105 );	
X_SETTEXTURE( 16,-1);
												ON_DEBUG ( 2, 106 );	
X_DRAWOBJ( 0,0);
												ON_DEBUG ( 2, 107 );	
X_SCALING( 1,1,1);
												ON_DEBUG ( 2, 109 );	
for (x = 0 ; x<= 39; x++)
{
												ON_DEBUG ( 2, 110 );		
for (y = 0 ; y<= 39; y++)
{
												ON_DEBUG ( 2, 111 );			
dx=px-x;
dy=y-py;
												ON_DEBUG ( 2, 112 );			
if (dx*dx+dy*dy <= radius)
{
												ON_DEBUG ( 2, 113 );				
num = city(x,y) ;
												ON_DEBUG ( 2, 114 );				
if (num<55)
{
												ON_DEBUG ( 2, 115 );					
X_SETTEXTURE( num, -1);
												ON_DEBUG ( 2, 116 );					
X_MOVEMENT( x*GLOBAL TileSize, 0, y*GLOBAL TileSize);
												ON_DEBUG ( 2, 117 );					
X_DRAWOBJ( 0, 0);
												ON_DEBUG ( 2, 118 );				
}
else
{
												ON_DEBUG ( 2, 119 );					
// select:
if (FALSE){
												ON_DEBUG ( 2, 120 );					
} else if( (num) == (55) ){												ON_DEBUG ( 2, 121 );						
X_SPRITE( num, (x+.5)*GLOBAL TileSize, 0, (y+.5)*GLOBAL TileSize, .15);
												ON_DEBUG ( 2, 122 );						
num = 16;
// gras 
												ON_DEBUG ( 2, 123 );					
} else if( (num) == (56) ){												ON_DEBUG ( 2, 124 );						
X_MOVEMENT( x*GLOBAL TileSize, 0, y*GLOBAL TileSize);
												ON_DEBUG ( 2, 125 );						
X_SETTEXTURE( num, -1);
												ON_DEBUG ( 2, 126 );						
X_DRAWOBJ( num, 0);
												ON_DEBUG ( 2, 127 );						
num = 0;
// Street 
												ON_DEBUG ( 2, 128 );					
}
// street - bottom 
												ON_DEBUG ( 2, 130 );					
X_SETTEXTURE( num, -1);
												ON_DEBUG ( 2, 131 );					
X_MOVEMENT( x*GLOBAL TileSize, 0, y*GLOBAL TileSize);
												ON_DEBUG ( 2, 132 );					
X_DRAWOBJ( 0, 0);
												ON_DEBUG ( 2, 133 );				
}
												ON_DEBUG ( 2, 134 );			
}
												ON_DEBUG ( 2, 135 );		
}
												ON_DEBUG ( 2, 136 );	
}
												ON_DEBUG ( 2, 137 );	
X_MIPMAPPING( FALSE);
												ON_DEBUG ( 2, 138 );
return 0;
}
// DRAWCITY 
// ------------------------------------------------------------- // 
// -=#  GETCITYCOLLISION  #=- 
// ------------------------------------------------------------- // 
// ------------------------ //
DGInt GetCityCollision(DGIntArray& truck)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGIntArray, truck);
// Diese Variablen sind als LOCAL definiert: 
// 
// Diese Werte werden per Referenz �bergeben: 
// truck[] 
												ON_DEBUG ( 2, 156 );
REGISTER_VAR_DEF(DGInt, hits, 0);
REGISTER_VAR_DEF(DGInt, i, 0);
REGISTER_VAR_DEF(DGInt, l1, 0);
REGISTER_VAR_DEF(DGInt, phi, 0);
REGISTER_VAR_DEF(DGInt, wd, 0);
												ON_DEBUG ( 2, 157 );	
wd=2.0/2;
// width of truck 
												ON_DEBUG ( 2, 158 );	
for (i = 0 ; i<= BOUNDS(truck(), 0)-1; i++)
{
												ON_DEBUG ( 2, 159 );		
l1  = truck(i,0)+.5;
// always .5 m longer than the hinge 
												ON_DEBUG ( 2, 160 );		
phi = truck(i,4) ;
												ON_DEBUG ( 2, 161 );		
hits=bOR(hits, CityAtPoint(	truck(i,2)+wd*SIN(phi),   									truck(i,3)-wd*COS(phi)) ) ;
												ON_DEBUG ( 2, 163 );		
hits=bOR(hits, CityAtPoint(	truck(i,2)-wd*SIN(phi),   									truck(i,3)+wd*COS(phi)) ) ;
												ON_DEBUG ( 2, 166 );		
hits=bOR(hits, CityAtPoint(	truck(i,2)+wd*SIN(phi)+l1*COS(phi),   									truck(i,3)-wd*COS(phi)+l1*SIN(phi)) ) ;
												ON_DEBUG ( 2, 168 );		
hits=bOR(hits, CityAtPoint(	truck(i,2)-wd*SIN(phi)+l1*COS(phi),   									truck(i,3)+wd*COS(phi)+l1*SIN(phi)) ) ;
												ON_DEBUG ( 2, 170 );		
l1 = truck(i,1) ;
												ON_DEBUG ( 2, 171 );		
hits=bOR(hits, CityAtPoint(	truck(i,2)+wd*SIN(phi)-l1*COS(phi),   									truck(i,3)-wd*COS(phi)-l1*SIN(phi)) ) ;
												ON_DEBUG ( 2, 173 );		
hits=bOR(hits, CityAtPoint(	truck(i,2)-wd*SIN(phi)-l1*COS(phi),   									truck(i,3)+wd*COS(phi)-l1*SIN(phi)) ) ;
												ON_DEBUG ( 2, 175 );	
}
												ON_DEBUG ( 2, 176 );	
return hits;
												ON_DEBUG ( 2, 177 );
return 0;
}
// GETCITYCOLLISION 
// ------------------------------------------------------------- // 
// -=#  CITYATPOINT  #=- 
// ------------------------------------------------------------- // 
// ------------------------ //
DGInt CityAtPoint(DGInt x, DGInt y)
{
  #undef __FKT
  #define __FKT __l_dbg_cont
  __VAR_CONTAINER __FKT;
ARGS_VAR(DGInt, x);
ARGS_VAR(DGInt, y);
// Diese Variablen sind als LOCAL definiert: 
// x, y 
												ON_DEBUG ( 2, 188 );
REGISTER_VAR_DEF(DGInt, pt, 0);
//	X_DRAWAXES x, -1, y // Debug 
												ON_DEBUG ( 2, 190 );	
x = x/GLOBAL TileSize;
												ON_DEBUG ( 2, 191 );	
y = y/GLOBAL TileSize;
												ON_DEBUG ( 2, 192 );	
if (x<0 OR y<0 OR x>=BOUNDS(city(), 0) OR y>=BOUNDS(city(),1) )
return 1;
												ON_DEBUG ( 2, 194 );	
pt = city(x,y) ;
												ON_DEBUG ( 2, 195 );	
// select:
if (FALSE){
												ON_DEBUG ( 2, 196 );		
} else if( (pt)>=(55) ){return 2;
// Wall 
												ON_DEBUG ( 2, 197 );		
} else if( (pt) >= (0 ) && (pt) <= ( 15) ){return 0;
// Road 
												ON_DEBUG ( 2, 198 );		
} else if( (pt) >= (16 ) && (pt) <= ( 49) ){return 2;
// Slow Down 
												ON_DEBUG ( 2, 199 );		
} else if( (pt) == (50) ){return 4;
// Shop 
												ON_DEBUG ( 2, 200 );	
}
												ON_DEBUG ( 2, 201 );
return 0;
}
// CITYATPOINT 
} // namespace
